/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rcw5k2moviess21;

/**
 *
 * @author raymondwaidmann
 */
public enum Genre {
    ACTION, ANIMATION, COMEDY, DRAMA, FANTASY, HORROR, ROMANCE, SCI_FI, SUSPENSE, WESTERN, UNKNOWN
}